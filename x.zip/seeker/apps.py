from django.apps import AppConfig


class SeekerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'seeker'
